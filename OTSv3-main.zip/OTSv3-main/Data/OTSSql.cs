﻿using Microsoft.EntityFrameworkCore;
using OTSv3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OTSv3.Data
{
    public class OTSSql : IOTS
    {
        private OTSv1Context OTSv1Context { get; }

        // Constructor
        public OTSSql(OTSv1Context oTSv1Context)
        {
            OTSv1Context = oTSv1Context;

        }

        public async Task<IEnumerable<PrmSinif>> SinifGetir()
        {
            return await OTSv1Context.PrmSinifs.ToListAsync();
        }
    }
}
