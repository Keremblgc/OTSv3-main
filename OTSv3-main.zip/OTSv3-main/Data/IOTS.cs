﻿using OTSv3.Models;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace OTSv3.Data
{
    public interface IOTS
    {
        // Kullanılacak fonksiyonlar burada tanımlanıyor

        Task<IEnumerable<PrmSinif>> SinifGetir();
    }
}
