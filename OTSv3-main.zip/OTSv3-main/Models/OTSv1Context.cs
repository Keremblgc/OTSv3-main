﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace OTSv3.Models
{
    public partial class OTSv1Context : DbContext
    {
        public OTSv1Context()
        {
        }

        public OTSv1Context(DbContextOptions<OTSv1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<DatOgrenci> DatOgrencis { get; set; }
        public virtual DbSet<DatUser> DatUsers { get; set; }
        public virtual DbSet<PrmSinif> PrmSinifs { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<DatOgrenci>(entity =>
            {
                entity.HasKey(e => e.OgrenciId);

                entity.ToTable("datOgrenci");

                entity.Property(e => e.OgrenciId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("OgrenciID");

                entity.Property(e => e.OgrAd)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.OgrCinsiyet)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.OgrDt)
                    .IsRequired()
                    .HasMaxLength(8)
                    .HasColumnName("OgrDT");

                entity.Property(e => e.OgrSoyad)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.SinifId).HasColumnName("SinifID");
            });

            modelBuilder.Entity<DatUser>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("datUser");

                entity.Property(e => e.UserId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("UserID");

                entity.Property(e => e.UserFname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("UserFName");

                entity.Property(e => e.UserLname)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasColumnName("UserLName");

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(10);

                entity.Property(e => e.UserPass)
                    .IsRequired()
                    .HasMaxLength(10);
            });

            modelBuilder.Entity<PrmSinif>(entity =>
            {
                entity.HasKey(e => e.SinifId);

                entity.ToTable("prmSinif");

                entity.Property(e => e.SinifId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("SinifID");

                entity.Property(e => e.SinifTnm)
                    .IsRequired()
                    .HasMaxLength(20);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
