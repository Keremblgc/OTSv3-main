﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OTSv3.Models
{
    public partial class PrmSinif
    {
        public byte SinifId { get; set; }
        public string SinifTnm { get; set; }
    }
}
