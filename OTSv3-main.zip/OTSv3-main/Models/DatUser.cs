﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OTSv3.Models
{
    public partial class DatUser
    {
        public byte UserId { get; set; }
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public string UserFname { get; set; }
        public string UserLname { get; set; }
    }
}
