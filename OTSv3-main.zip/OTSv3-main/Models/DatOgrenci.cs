﻿using System;
using System.Collections.Generic;

#nullable disable

namespace OTSv3.Models
{
    public partial class DatOgrenci
    {
        public byte OgrenciId { get; set; }
        public short OgrNo { get; set; }
        public string OgrAd { get; set; }
        public string OgrSoyad { get; set; }
        public byte SinifId { get; set; }
        public string OgrDt { get; set; }
        public string OgrCinsiyet { get; set; }
    }
}
